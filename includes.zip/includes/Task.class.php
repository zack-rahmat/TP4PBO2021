<?php 

/******************************************
PRAKTIKUM RPL
******************************************/

class Task extends DB{
	
	// Mengambil data
	function getTask(){
		// Query mysql select data ke tb_form17agustus
		$query = "SELECT * FROM tb_form17agustus";

		// Mengeksekusi query
		return $this->execute($query);
	}

	function insertTask($data){
		$tteamname = $data['tteamname'];
		$tleader = $data['tleader'];
		$taddres = $data['taddres'];
		$tnotelp = $data['tnotelp'];
		$ttype = $data['ttype'];
		$tstatus = "Belum Terdaftar";

		$query = "INSERT INTO tb_form17agustus (nama_tim, ketua_tim, alamat, no_telp, jenis_lomba, status) VALUES ('$tteamname', '$tleader', '$taddres', '$tnotelp', '$ttype', '$tstatus')";

		// Mengeksekusi query
		return $this->execute($query);
	}

	function deleteTask($id){
		$query = "DELETE FROM tb_form17agustus WHERE id=$id";

		return $this->execute($query);
	}

	function updateTask($id){
		$query = "UPDATE tb_form17agustus SET status = 'Sudah Terdaftar' WHERE id = $id";

		return $this->execute($query);
	}
}



?>
